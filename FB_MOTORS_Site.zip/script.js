// Script simples
console.log('Site da AutoHub carregado');
